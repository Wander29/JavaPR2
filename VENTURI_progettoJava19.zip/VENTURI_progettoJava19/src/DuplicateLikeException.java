
public class DuplicateLikeException extends RuntimeException {
	public DuplicateLikeException() { super(); }
	
	public DuplicateLikeException(String s) { super(s); }
}
