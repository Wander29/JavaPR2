
public class HiddenCategoryException extends RuntimeException{
	public HiddenCategoryException(String s) { super(s); }
	
	public HiddenCategoryException() { super(); }
}

